Rekap Keuangan Ersn v2 - Siap Pakai (Offline, Mobile-first)
==============================================================

Instruksi cepat:
1. Ekstrak file ZIP.
2. Buka folder 'Rekap Keuangan Ersn v2' lalu buka file index.html di browser (Chrome/Safari).
3. Untuk akses seperti aplikasi: Add to Home Screen.

Perbaikan di v2:
- Metatag viewport untuk mobile.
- Chart dibungkus di container ber-height tetap agar tidak melebar.
- Chart library minimal tertanam sehingga bekerja offline.
- Grafik otomatis terupdate saat menambah/hapus data tanpa perlu refresh.
- Tema otomatis mengikuti pengaturan perangkat (dark / light).

Data disimpan di localStorage browser.
